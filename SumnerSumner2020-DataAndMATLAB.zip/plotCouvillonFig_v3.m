function sh = plotCouvilonFig_v3(data,option)

if nargin>1 && strcmp(option,'push')
    push = 1;
else
    push = 0;
end;

% compute overall % correct and pc max.
data.pc = (data.hr + 1-data.fa)/2;
data.pcmax = normcdf( data.dp/2 );

xvals = [-10:0.01:10];
nrows = 4; %length(data.dp);
nsdtrows = 3;

xlm = [-3-max(data.dp) max(data.dp)+3];
bary = max([data.hr data.fa]*1.2);

dataw = 0.3;
sdtw = 0.28;
figw_cm = 12;
xpad = 0.03;
sdtstatsw = 0.4;



figh_cm = 2.5*nrows;
f = figure('position',[100 20 60*figw_cm 60*figh_cm], ...
           'papersize',[figw_cm figh_cm]);

panelh = 0.6/nrows;
panelgap = 0.05;
x0_cm = 0.1;

ri = 1;   
% Plot the original data as acceptance rate. 
subplot('position',[2*xpad 1-ri*(panelh+panelgap) dataw panelh]);
plot([1:5],[data.hr;data.fa],'.','markersize',12); 
%xlabel('Condition');
ylabel('Acceptance rate');
ylim([0 1]); xlim([0 6]);set(gca,'xticklabel',[]);
box off;
text(0,1.2,['A. Acceptance rates in ' data.species 's'],'fontweight','bold');
axislabel(gca);
text(1.4,-.45,'Experimental context');

 
% Plot the original data as proportion correct.. 
ri= 1;
subplot('position',[12*xpad+dataw 1-ri*(panelh+panelgap) dataw panelh]);
plot([1:5],[data.hr;1-data.fa],'.','markersize',12); hold on;
plot([1:5],[data.pc],'.-','markersize',12); 

%xlabel('Condition');
ylabel('Proportion correct');  box off;
ylim([0 1]); xlim([0 6]);set(gca,'xticklabel',[]);
text(0,1.2,'B. Proportion correct','fontweight','bold');
line([0 6],[0.5 0.5],'linestyle','--','linewidth',1,'color',[.7 .7 .7]);
text(.1,.45,'chance','color',[.7 .7 .7],'fontsize',8);
axislabel(gca);
text(1.4,-0.45,'Experimental context');

lh  = legend('Nestmates','Non-nestmates','Average(NM,NNM)');
set(lh,'box','off','location','southwest');

% ---------------------------------------------------------------------
% ---------------        plot the SDT summary         -------------------

% d'. 
ri= 4.5;
sh(1) = subplot('position',[xpad*2 1-ri*(panelh+panelgap) sdtstatsw 1.2*panelh]);
colord = get(gca,'colororder');
plot([1:5],[data.dp],'+','markersize',12,'linewidth',2,'color',colord(3,:)); 
ylabel('Cue sensitivity (d'')'); set(gca,'xticklabel',[]);
ylim([-.2 3]); xlim([0 6]); box off;
text(1.4,-1.5,'Experimental context');
line([0 6],[0 0],'linestyle','--','color',[.7 .7 .7]);
text(.1,.3,'chance','color',[.5 .5 .5],'fontsize',8);
text(0,3.6,'D. Summary of SDT statistics','fontweight','bold');
axislabel(gca);

   
sh(2) = subplot('position',[5.5*xpad+sdtstatsw 1-ri*(panelh+panelgap) sdtstatsw 1.2*panelh]);
plot([1:5],[data.c],'xk','markersize',10,'linewidth',2); 
ylabel('Decision criterion (c)');
ylim([-2 1]); box off;
xlim([0 6]);set(gca,'xticklabel',[]);
text(1.4,-3.2,'Experimental context');
line([0 6],[0 0],'linestyle','--','color',[.7 .7 .7]);
text(5.3,-.2,'no-bias','color',[.5 .5 .5],'fontsize',8);
axislabel(gca);



% ------------------------------------------------------------
% --------------- plot the SDT distributions    --------------

ri = 2.6; dpi = 1;
lw = 2;
cNM = 1; cNNM = 2; cNM2 = 5; cNNM2 = 6;  % Color orders of lines. 
critColor = [.7 .7 .7];
ymax = 0.8;

%  ---------- SDT model in the hive --------- 
subplot('position',[2*xpad 1-ri*(panelh+panelgap) sdtw panelh]);
colord = get(gca,'colororder');   % Get the default colour order.
hold on;
% Plot the basic lines.
plot(xvals,normpdf(xvals,-0.5*data.dp(dpi)),'linewidth',lw,'color',colord(cNNM,:));
plot(xvals,normpdf(xvals,0.5*data.dp(dpi)),'linewidth',lw,'color',colord(cNM,:));
% Plot the distrubtion. 
normPDFpatch(xvals,data.c(dpi),data.dp(dpi));
% Replot the lines.
plot(xvals,normpdf(xvals,-0.5*data.dp(dpi)),'linewidth',lw,'color',colord(cNNM,:));
plot(xvals,normpdf(xvals,0.5*data.dp(dpi)),'linewidth',lw,'color',colord(cNM,:));
% d' and c lines.
line([data.c(dpi) data.c(dpi)],[0 ymax*.95],'color',critColor,'linestyle','--','linewidth',lw);
th = text(data.c(dpi)-.45,ymax*.58 ,['c:' num2str(round(data.c(dpi),1))],'color',critColor,'fontweight','bold');
set(th,'rotation',90);
text(-0.25+data.dp(dpi)/2,0.52 ,['d'':' num2str(round(data.dp(dpi),2))]); 
line(0.5*[-data.dp(dpi) data.dp(dpi)],[0.42 .42],'color','k');
% Labels and titles
text(xlm(1),ymax*.78/.6,['C. SDT models of ' data.species ' guard behaviour'],'fontweight','bold');
xlabel('Sensory cue');
text(xlm(1)*0.95,ymax*1.1,data.DVnames{dpi});
% Finish off.
xlim(xlm); ylim([0 ymax]);box off;
set(gca,'xtick',[-5:5]);lh = legend('Non-nestmates (NNM)/hive','Nestmates (NM)/hive');
set(lh,'box','off');
ylabel('Probability (AU)')


%  ---------- SDT model with odour ---------  
dpdiff = abs(data.dp(2)-data.dp(3));
dpoffset = 0;
if dpdiff < 0.2;
    dpoffset = 0.1;
end;

dpi = 2; % 2 guards.
subplot('position',[3*xpad+sdtw 1-ri*(panelh+panelgap) sdtw panelh]);
plot(xvals-dpoffset,normpdf(xvals,-0.5*data.dp(dpi)),'color',colord(cNNM,:),'linewidth',lw);
hold on;
plot(xvals-dpoffset,normpdf(xvals,0.5*data.dp(dpi)),'color',colord(cNM,:),'linewidth',lw);

line([data.c(dpi) data.c(dpi)],[0 ymax*.95],'color',critColor,'linestyle','--','linewidth',lw);

text(-0.25+data.dp(dpi)/2,0.52 ,['d'': ~' num2str(round(data.dp(dpi),1))]); 
line(0.5*[-data.dp(dpi) data.dp(dpi)],[0.42 .42],'color','k');

dpi = 3; % 1-guard.
plot(xvals+dpoffset,normpdf(xvals,-0.5*data.dp(dpi)),'-','color',colord(cNNM2,:),'linewidth',lw);
hold on;
plot(xvals+dpoffset,normpdf(xvals,0.5*data.dp(dpi)),'-','color',colord(cNM2,:),'linewidth',lw);
line([data.c(dpi) data.c(dpi)],[0 ymax*.95],'color',critColor,'linestyle','--','linewidth',lw);
th = text(data.c(dpi)-.45,ymax*0.58 ,['c:' num2str(round(data.c(dpi),1))],'color',critColor,'fontweight','bold');
set(th,'rotation',90);
line(0.5*[-data.dp(dpi) data.dp(dpi)],[0.42 .42],'color','k');

% Tidy up.
text(xlm(1)*0.95,ymax*1.1,'arena with odour');
xlabel('Sensory cue');
xlim(xlm); ylim([0 ymax]);box off; 
set(gca,'xtick',[-5:5],'yticklabel',[]);
lh = legend('NNM/2-Gd','NM/2-Gd'); %,'NNM/1-Gd','NM/1-Gd');
set(lh,'box','off');


% -------------- SDT model with no odour -------------------
dpdiff = abs(data.dp(4)-data.dp(5));
dpoffset = 0;
if dpdiff < 0.2;
    dpoffset = 0.075;
end;

% Plot the SDT model. 
subplot('position',[4*xpad+2*sdtw 1-ri*(panelh+panelgap) sdtw panelh]);

dpi =5;
plot(xvals-dpoffset,normpdf(xvals,-0.5*data.dp(dpi)),'-','color',colord(cNNM2,:),'linewidth',lw);
hold on;
plot(xvals-dpoffset,normpdf(xvals,0.5*data.dp(dpi)),'-','color',colord(cNM2,:),'linewidth',lw);

line([data.c(dpi) data.c(dpi)],[0 ymax*0.95],'color',critColor,'linestyle','--','linewidth',lw);
th = text(data.c(dpi)-.45,ymax*.58,['c:' num2str(round(data.c(dpi),1))],'color',critColor,'fontweight','bold');
set(th,'rotation',90);

text(-0.25+data.dp(dpi)/2,0.52 , ...
    ['d'':~' num2str(round(data.dp(dpi),1)) ]); 
line(0.5*[-data.dp(dpi) data.dp(dpi)],[0.42 .42],'color','k');

dpi = 4;
plot(xvals+dpoffset,normpdf(xvals,-0.5*data.dp(dpi)),'color',colord(cNNM,:),'linewidth',lw);
hold on;
plot(xvals+dpoffset,normpdf(xvals,0.5*data.dp(dpi)),'color',colord(cNM,:),'linewidth',lw);

line([data.c(dpi) data.c(dpi)],[0 ymax*.95],'color',critColor,'linestyle','--','linewidth',lw);
line(0.5*[-data.dp(dpi) data.dp(dpi)],[0.42 .42],'color','k');

% Tidy up. 
text(xlm(1)*0.95,ymax*1.1,'arena without odour');
xlim(xlm);
ylim([0 ymax]);
set(gca,'xtick',[-5:5],'yticklabel',[]);
xlabel('Sensory cue');box off;
lh = legend('NNM/1-Gd','NM/1-Gd');
set(lh,'box','off');


function axislabel(ah)
subplot(ah);
ylm = ylim;
yl = ylm(1)-0.28*diff(ylm);
set(gca,'xtick',[1:5],'xticklabel',{'hive','2-Gd','1-Gd','2-Gd','1-Gd'});
th = text([2 4],[yl yl],{'Odour','No-odour'},'fontsize',8);




