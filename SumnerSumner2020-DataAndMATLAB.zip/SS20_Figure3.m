%% --------------- Figure 3 from Sumner&Sumner Royal.Soc. 2020  ------------------

% Honey bee data originally published by Coubillon et al. (2013):
% Couvillon, M. J., Segers, F. H. I. D., Cooper-Bowman, R., Truslove, G., 
% Nascimento, D. L., Nascimento, F. S. & Ratnieks, F. L. W. (2013) 
% Context affects nestmate recognition errors in honey bees and stingless bees. 
% J Exp Biol 216, 3055-3061. (DOI:10.1242/jeb.085324).
% Data was provided by Francisca Segers, reformatted slightly for the data analysis.

% Initialise functions for SDT.
init_sdtmodel

% Load up the honeybee data.
honey.data = readtable('honeybee.csv')     

% Make table of statistics.
honey.stats = unstack(honey.data,'Response','NNMBee','GroupingVariables','Treatment','AggregationFunction', @mean);
honey.stats.Properties.VariableNames = {'Treatment','NNM','NM'};
honey.stats.TreatmentName = {'hive','T1.Gd1Od0','T2.Gd2Od0','T3.Gd1Od1','T4.Gd2Od1'}';
% Add in d' analysis.
ntmp = unstack(honey.data,'Response','NNMBee','GroupingVariables','Treatment','AggregationFunction', @length);
ntmp.Properties.VariableNames = {'Treatment','NNM','NM'};
honey.stats.n_NM = ntmp.NM; honey.stats.n_NNM = ntmp.NNM;
honey.stats.Z_NM = Zfn(honey.stats.NM);
honey.stats.Z_NNM = Zfn(honey.stats.NNM);
honey.stats.dprime = dPrimeFn(honey.stats.NM,honey.stats.NNM);
honey.stats.c = cCritFn(honey.stats.NM,honey.stats.NNM);

% Make a structure for the SDT plot.
treatmentOrder = [1 5 4 3 2 ];
honey.sdt.title = 'Couvillon et al. (2013). Fig. 2A. Honey bee';
honey.sdt.hr = honey.stats.NM(treatmentOrder)';  % Put in the order of Couvillon.  
honey.sdt.fa =  honey.stats.NNM(treatmentOrder)';
honey.sdt.IVname = '% acceptance';
honey.sdt.DVnames = honey.stats.TreatmentName(treatmentOrder)';
honey.sdt.HitClass = 'Nestmate';
honey.sdt.FAClass = 'Non-nestmate';
honey.sdt.dp = honey.stats.dprime(treatmentOrder)';
honey.sdt.c = honey.stats.c(treatmentOrder)';
honey.sdt.species = 'Honey Bee';

% Plot for the paper. 
sh = plotCouvillonFig_v3(honey.sdt);
