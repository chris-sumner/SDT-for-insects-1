% initialise sdt functions.


% Defining the Z values from proportions.
% Function is bounded in order to prevent +/- infinity. 
Zfn = @(prop) norminv(max(.001,min(prop,.999)));

% dPrime function 
dPrimeFn = @(hr,fa) Zfn(hr) - Zfn(fa);

% Criterion function (c). 
cCritFn  = @(hr,fa) -(Zfn(hr) + Zfn(fa))/2;

% Converting Z's back into proportional answers.
PropFn = @(Z) normcdf(Z);

% Deriving hit rate from d' and c (rearrange the above).
% Z(FA) = -(2c + Z(HR))
% dp = 2Z(HR) + 2c 
% Z(HR) = dp/2 - c 
HRFn = @(dp,c) PropFn(dp/2 - c);

% Deriving false alarm rate from d' and c.
% Z(HR) = -(2c + Z(FA))
% dp =  -2c - 2Z(FA) 
% Z(FA) = -(dp/2 + c) 
FAFn = @(dp,c) PropFn( -dp/2 - c );

