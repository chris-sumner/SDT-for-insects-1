function plotROCasSDT(data,ah)

% Fairly rough hacked figure.

xvals = [-10:0.01:10];
nrows = 2;
xlm = [-4 +4];

% Plot the SDT model for the Water condition. 
subplot(ah); hold on;

% Plot patches
normPDFpatch(xvals,data.c.Wat(190),data.dp.Wat);

l_fa = plot(xvals,normpdf(xvals,-0.5*data.dp.Wat),'linewidth',2);
l_h = plot(xvals,normpdf(xvals,0.5*data.dp.Wat),'linewidth',2);
xlim(xlm);
ylim([0 0.8]);
box off;



% Plot the criterion position for various "thresholds"     
cvals = [1 2 4 9 ];
ci = length(data.c.Wat)+1-cvals;

% Plot the hit and false alarm areas for 5 actions.
c_index = 3;
fapatchx = [data.c.Wat(ci(c_index)) xvals(xvals>data.c.Wat(ci(c_index))) ];
fapatchy = [0 normpdf(xvals(xvals>data.c.Wat(ci(c_index))),-data.dp.Wat/2,1) ];
hitpatchx =  [data.c.Wat(ci(c_index)) xvals(xvals>data.c.Wat(ci(c_index))) ];
hitpatchy = [0 normpdf(xvals(xvals>data.c.Wat(ci(c_index))),data.dp.Wat/2,1) ];

h_col = get(l_h,'color'); h_col = h_col + 0.5*(1-h_col)
f_col = get(l_fa,'color'); f_col = f_col + 0.5*(1-f_col)

hph = patch(hitpatchx,hitpatchy,h_col);
set(hph,'facealpha',1,'edgecolor',get(l_h,'color'));
fph = patch(fapatchx,fapatchy,f_col);
set(fph,'facealpha',1,'edgecolor',get(l_fa,'color'));

arrayfun(@(x) line([x x],[0 0.55],'color',[.7 .7 .7],'linestyle','--','linewidth',2),data.c.Wat(ci));
arrayfun(@(x,y) text(x-.05,.6,num2str(y),'color',[.5 .5 .5]),data.c.Wat(ci),cvals);
text(-3.5,0.6,'# Responses:','color',[.5 .5 .5]);

line(0.5*[-data.dp.Wat data.dp.Wat],[0.42 .42],'color','k','linewidth',2);
text(-1+data.dp.Wat/2,0.46 ,['d'':' num2str(round(data.dp.Wat,2))]); 
text(xlm(1)*0.9,0.8*1.1,'B. SDT representation','fontweight','bold');

lh= legend('nestmates','non-nestmates','location','northeast');
set(lh, 'box','off');

% % Plot the SDT model for the Water condition. 
% subplot(2,2,4);
% plot(xvals,normpdf(xvals,-0.5*data.dp.For));
% hold on;
% plot(xvals,normpdf(xvals,0.5*data.dp.For));
% xlim(xlm);
% ylim([0 0.8]);
% box off;
% ylabel('Probability (AU)');
% 
% % Plot the criterion position for various "thresholds"     
% cvals = [1 2 5 20 ];
% ci = length(data.c.For)+1-cvals;
% 
% arrayfun(@(x) line([x x],[0 0.6],'color','k','linestyle','--'),data.c.For(ci));
% arrayfun(@(x,y) text(x-.05,.65,num2str(y)),data.c.For(ci),cvals);
% text(-2,0.65,'# Actions');
% 
% line(0.5*[-data.dp.For data.dp.For],[0.42 .42],'color','k');
% text(-0.25+data.dp.For/2,0.48 ,['d'':' num2str(round(data.dp.For,2))]); 
% text(xlm(1)*0.9,0.8*1.1,'D. Formic acid','fontweight','bold');
xlabel('Sensory cue (AU)');
ylabel('Probability (AU)');

