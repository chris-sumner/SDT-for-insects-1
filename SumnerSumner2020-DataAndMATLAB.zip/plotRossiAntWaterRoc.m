function plotRossiAntRoc(data,measi,ah,dplist,cat,cumflag,ciflag,alpha)

init_sdtmodel;

% Function to jitter data for diplay (for individual points).
jitter = @(x) x - 0.01 + 0.02*rand(size(x));

if nargin<6
    cumflag = true;
end;

if nargin<7
    ciflag = true;
end;

if nargin<8
    alpha = 1;
end;

[respCDFs, pvals, respHist, rocboot] = RossiROC(data,measi,cat,1000,cumflag);

% ----------- plot ---------------

subplot(ah);
hold on;
axis([-.02 1 0 1]);
% Equality line.
xlabel('nestmates (aggression = false alarm)');
ylabel('non-nestmates (aggression = hit)');

% Neighbours vs. nestmates: water 
colb = [ 0 0 0 ]; 

p1 = plot(respCDFs.WatNM,respCDFs.WatNonNM,'o','color',colb,'markerface',colb);
hold on;
 arrayfun(@(x,y,c) text(x,y,num2str(c)),respCDFs.WatNM(1:4),respCDFs.WatNonNM(1:4),[1:4]);

% d' for eq var. SDT.
if nargin>2
    for di = 1:length(dplist)
        plot(normcdf(pvals,dplist(di),1),normcdf(pvals,0,1),'-','color',[.7 .7 .7],'linewidth',2)
        hold on;
        text(normcdf(1,dplist(di),1), normcdf(2,0,1),['d''=' num2str(dplist(di))], ...
            'color',[.7 .7 .7],'fontweight','bold')
    end;
end;


if ciflag
    % Draw errorbars.
    arrayfun(@(x1,x2,y)  line([x1 x2],[y y],'color',colb), ...
        rocboot.WatNM.quantiles(:,1), rocboot.WatNM.quantiles(:,5), ...
       fliplr( respCDFs.WatNonNM )' );                    
    arrayfun(@(y1,y2,x)  line([x x],[y1 y2],'color',colb), ...
        rocboot.WatNonNM.quantiles(:,1), rocboot.WatNonNM.quantiles(:,5), ...
        fliplr(respCDFs.WatNM)' );

    % Replot so they come on top. 
    plot(respCDFs.WatNM,respCDFs.WatNonNM,'o','color',colb,'markerface',colb);

    arrayfun(@(x,y,t) text(x,y,sprintf('%d+',t)), ...
        respCDFs.WatNM(200:-1:197)-.07,respCDFs.WatNonNM(200:-1:197)+.07,[1:4]);
end;

line([0 1],[0 1],'color',[.7 .7 .7],'linestyle','--');

d1 = sum(dPrimeFn(respCDFs.WatNonNM,respCDFs.WatNM))/ ...
     sum(dPrimeFn(respCDFs.WatNonNM,respCDFs.WatNM)>0);

d2 = sum(dPrimeFn(respCDFs.ForNonNM,respCDFs.ForNM))/ ...
     sum(dPrimeFn(respCDFs.ForNonNM,respCDFs.ForNM)>0);

 if isempty(dplist)
     dplist = [d1 d2];
 end;

title(respHist.title);
