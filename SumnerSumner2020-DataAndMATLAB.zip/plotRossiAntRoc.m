function plotRossiAntRoc(data,measi,ah,dplist,cat,cumflag,ciflag,alpha)

init_sdtmodel;

% Function to jitter data for diplay (for individual points).
jitter = @(x) x - 0.01 + 0.02*rand(size(x));

if nargin<6
    cumflag = true;
end;

if nargin<7
    ciflag = true;
end;

if nargin<8
    alpha = 1;
end;

[respCDFs, pvals, respHist, rocboot] = RossiROC(data,measi,cat,1000,cumflag);

% ----------- plot ---------------

subplot(ah);
hold on;
axis([0 1 0 1]);
% Equality line.
xlabel('nestmates (aggression = false alarm)');
ylabel('non-nestmates (aggression = hit)');

colord = get(gca,'colororder');

% Neighbours vs. nestmates: water 
colb = colord(6,:);
p1 = plot(respCDFs.WatNM,respCDFs.WatNonNM,'o','color',colb,'markerface',colb);

% Neighbours vs. non-nestmates: formic acid
colr = colord(7,:);
p2 = plot(respCDFs.ForNM,respCDFs.ForNonNM,'o','color',colr,'markerface',colr);


if ciflag
    % Draw errorbars.
    arrayfun(@(x1,x2,y)  line([x1 x2],[y y],'color',colb), ...
        rocboot.WatNM.quantiles(:,1), rocboot.WatNM.quantiles(:,5), ...
       fliplr( respCDFs.WatNonNM )' );                    
    arrayfun(@(y1,y2,x)  line([x x],[y1 y2],'color',colb), ...
        rocboot.WatNonNM.quantiles(:,1), rocboot.WatNonNM.quantiles(:,5), ...
        fliplr(respCDFs.WatNM)' );

    arrayfun(@(x1,x2,y)  line([x1 x2],[y y],'color',colr), ...
        rocboot.ForNM.quantiles(:,1), rocboot.ForNM.quantiles(:,5), ...
        fliplr(respCDFs.ForNonNM)' );                    
    arrayfun(@(y1,y2,x)  line([x x],[y1 y2],'color',colr), ...
        rocboot.ForNonNM.quantiles(:,1), rocboot.ForNonNM.quantiles(:,5), ...
        fliplr(respCDFs.ForNM)' );
    
    % Replot so they come on top. 
    plot(respCDFs.WatNM,respCDFs.WatNonNM,'o','color',colb,'markerface',colb);
    plot(respCDFs.ForNM,respCDFs.ForNonNM,'o','color',colr,'markerface',colr);
end;

line([0 1],[0 1],'color',[.7 .7 .7],'linestyle','--');

d1 = sum(dPrimeFn(respCDFs.WatNonNM,respCDFs.WatNM))/ ...
     sum(dPrimeFn(respCDFs.WatNonNM,respCDFs.WatNM)>0);

d2 = sum(dPrimeFn(respCDFs.ForNonNM,respCDFs.ForNM))/ ...
     sum(dPrimeFn(respCDFs.ForNonNM,respCDFs.ForNM)>0);

 if isempty(dplist)
     dplist = [d1 d2];
 end;
 
% d' = 0.8 line for eq var. SDT.
if nargin>2
    for di = 1:length(dplist)
        plot(normcdf(pvals,dplist(di),1),normcdf(pvals,0,1),'--','color',[.7 .7 .7])
        text(normcdf(0.5,dplist(di),1), normcdf(0.5,0,1), num2str(dplist(di)))
    end;
end;
lh = legend('water','formic acid','location','southeast');
set(lh,'box','off');

title(respHist.title);
