%% ------------ Sumner&Sumner Royal. Soc. 2020 - Figure 2 --------------

% Reproduces data from Alves-Pinto et al. 2012:
% Alves-Pinto A, Sollini J, Sumner CJ (2012) Signal detection in animal 
% psychoacoustics: analysis and simulation of sensory and decision-related influences. 
% Neuroscience 220:215-227.

load yesnodata;

init_sdtmodel

% N.B. This is a very rudimetary analysis.
cherry.meth_limits.rawtable = struct2table(rmfield(cherry.meth_limits.rawdata,'masker_atten'))
cherry.meth_limits.stats = unstack(cherry.meth_limits.rawtable,'answer','speaker','GroupingVariables', ...
        'attens_per_trial','AggregationFunction', @mean);
cherry.meth_limits.stats.Properties.VariableNames = {'atten_dB','no_sound','sound'};
cherry.meth_limits.stats.dprime = dPrimeFn(cherry.meth_limits.stats.sound,cherry.meth_limits.stats.no_sound);
cherry.meth_limits.stats.c = cCritFn(cherry.meth_limits.stats.sound,cherry.meth_limits.stats.no_sound);

cherry.meth_const.rawtable = struct2table(rmfield(cherry.meth_const.rawdata,'masker_atten'))
cherry.meth_const.stats = unstack(cherry.meth_const.rawtable,'answer','speaker','GroupingVariables', ...
        'attens_per_trial','AggregationFunction', @mean);
cherry.meth_const.stats.Properties.VariableNames = {'atten_dB','no_sound','sound'};
cherry.meth_const.stats.dprime = dPrimeFn(cherry.meth_const.stats.sound,cherry.meth_const.stats.no_sound);
cherry.meth_const.stats.c = cCritFn(cherry.meth_const.stats.sound,cherry.meth_const.stats.no_sound);


%% ---------------- ROC data ------------------

% Load up the ROC data which is redigitised from an old figure. 
% I could not find the original data.
[~, ~, roc.raw] = xlsread('roc_datasets.xls');
roc.sessions = cell2table(roc.raw(3:end,1:2),'VariableNames',{'falsealarms','hits'})
roc.conditions = cell2table(roc.raw(3:11,3:4),'VariableNames',{'falsealarms','hits'})


%%  figure which shows that d' is stable, criterion is changing. 
figw_cm = 12; 
figh_cm = 10;

f = figure('position',[100 20 60*figw_cm 55*figh_cm], ...
           'papersize',[figw_cm figh_cm]);

subplot('position',[.08 .6 .3 .35]);
cord = get(gca,'colororder');
attens = [30:5:55];
reflvl = 100;
lw = 1;
props = {'markersize',8};

[~, p_mc] = ismember(attens, cherry.meth_const.stats.atten_dB);
plot(reflvl-cherry.meth_const.stats.atten_dB(p_mc), cherry.meth_const.stats.sound(p_mc),'.-','color',cord(1,:),'linewidth',lw, ...
    'markersize',12); 
hold on;
plot(reflvl-cherry.meth_const.stats.atten_dB(p_mc), cherry.meth_const.stats.no_sound(p_mc),'.-','color',cord(2,:),'linewidth',lw, ...
    'markersize',12);

[~, p_ml] = ismember(attens, cherry.meth_limits.stats.atten_dB);
plot(reflvl-cherry.meth_limits.stats.atten_dB(p_ml), cherry.meth_limits.stats.sound(p_ml),'--s','color',cord(1,:),'linewidth',lw, ...
    'markersize',4); 
plot(reflvl-cherry.meth_limits.stats.atten_dB(p_ml), cherry.meth_limits.stats.no_sound(p_ml),'--s','color',cord(2,:),'linewidth',lw, ...
    'markersize',4);

 axis([40 75 0 1]);
 ylabel('Proportion of "yes" responses');
 box off; 
 text(40,1.1, 'A. Hit and false alarm rates','fontweight','bold');
 lh = legend('Hits (MCS)','False alarms (MCS)','Hits (ML)','False alarms (ML)');
 set(lh,'box','off','fontsize',8);
 
subplot('position',[.65 .6 .3 .35]);
plot(reflvl-cherry.meth_const.stats.atten_dB(p_mc), cherry.meth_const.stats.dprime(p_mc),'.-','color',cord(3,:),'linewidth',lw, ...
    'markersize',12); 
hold on;
plot(reflvl-cherry.meth_limits.stats.atten_dB(p_ml), cherry.meth_limits.stats.dprime(p_ml),'--s','color',cord(3,:),'linewidth',lw, ...
    'markersize',4); 
 axis([40 75 -.3 3]);
 line([0 100],[0 0],'linestyle','--','color',[.7 .7 .7],'linewidth',1);
 xlabel('Tone sound level (dB SPL)'); ylabel('Sensitivity (d'')');
 box off; 
 text(40,3.33, 'B. Sensitivity to stimulus','fontweight','bold');
 lh = legend('MCS','ML');
 set(lh,'box','off','fontsize',8);

 
subplot('position',[.08 .1 .3 .35]);
plot(reflvl-cherry.meth_const.stats.atten_dB(p_mc), cherry.meth_const.stats.c(p_mc),'.-','color','k','linewidth',lw, ...
    'markersize',12); 
hold on;
plot(reflvl-cherry.meth_limits.stats.atten_dB(p_ml), cherry.meth_limits.stats.c(p_ml),'--s','color','k','linewidth',lw, ...
    'markersize',4); 
 axis([40 75 -1 1]);
 line([0 100],[0 0],'linestyle','--','color',[.7 .7 .7],'linewidth',1);
 xlabel('Tone sound level (dB SPL)'); ylabel('Criterion (c)');
 box off; 
 text(40,1.2, 'C. Decision criterion','fontweight','bold');
 lh = legend('MCS','ML');
 set(lh,'box','off','fontsize',8);

% Plot the ROC. 
subplot('position',[.65 .1 .3 .35]);

% Make the prediction of the SDT.
roccurve.dp = 1.4;
roccurve.hits = 1-normcdf([-3:.1:3],roccurve.dp/2,1);
roccurve.falsealarms = 1-normcdf([-3:.1:3],-roccurve.dp/2,1); hold on;

% plot the data
plot(roccurve.falsealarms,roccurve.hits,'color',[.7 .7 .7],'linewidth',2);
plot(roc.sessions.falsealarms,roc.sessions.hits,'dk');
hold on;
plot(roc.conditions.falsealarms,roc.conditions.hits,'sk','markerface','k');
lh = legend('SDT model','data by session','data by reward');
set(lh,'box','off');
ylabel('Hits'); xlabel('False alarms');
xlim([0, 1.02]); ylim([0,1.02]);
text(0,1.13, 'D. Receiver Opeating Characteristic','fontweight','bold');
set(gca,'xtick',[0:.2:1],'ytick',[0:.2:1]);



