%% --------------------- Figure 4 - Sumner&Sumner 2020 --------------------

% Data originally appear in Rossi et al. 2019:
% Rossi N, Baracchi D, Giurfa M, d'Ettorre P (2019) 
% Pheromone-Induced Accuracy of Nestmate Recognition in Carpenter Ants: 
% Simultaneous Decrease in Type I and Type II Errors. Am Nat 193:267-278.

% Data were available from: https://dx.doi.org/10.5061/dryad.14k55m8

filename = 'Rossietal2019_data';  
[~, ~, rossiexp2_raw] = xlsread(filename,2);

init_sdtmodel;

% Put the occurence data in a table. 
rossi2.occur = cell2table(rossiexp2_raw(3:140,1:8), ...
    'VariableNames',{'Colony','Treatment','Condition','ID','MandibleOpen','Biting','GasterFlex','Sum'});

% The sum of "occurance" is not correct in the data file.
% It only adds the last two columns - not MOR. 
% The duration data is calculated correctly. 
rossi2.occur{:,8} = sum(rossi2.occur{:,5:7},2);

% Flags for each condition
FAtreat =  strcmp(rossi2.occur.Treatment,'formic acid');
NNcond =  strcmp(rossi2.occur.Condition,'non-nestmate');

% Calcuate the mean numbers of aggressive behaviours for each ant in each condition.
% And the standard error of the number of aggressive behaviours.
% This replicates the values shown by the authors in the paper. 
rossi2.sumAggr = cell2table( ...
   {'formic acid','formic acid','water','water'; ...
    'nestmate','non-nestmate','nestmate','non-nestmate'; ...
    mean(rossi2.occur{FAtreat & ~NNcond,8}) ...
        mean(rossi2.occur{FAtreat & NNcond,8}) ...
        mean(rossi2.occur{~FAtreat & ~NNcond,8}) ...
        mean(rossi2.occur{~FAtreat & NNcond,8}) ;
    std(rossi2.occur{FAtreat & ~NNcond,8})/sqrt(sum(FAtreat & ~NNcond)) ...
        std(rossi2.occur{FAtreat & NNcond,8})/sqrt(sum(FAtreat & NNcond)) ...                                    
        std(rossi2.occur{~FAtreat & ~NNcond,8})/sqrt(sum(~FAtreat & ~NNcond)) ...
        std(rossi2.occur{~FAtreat & NNcond,8})/sqrt(sum(~FAtreat & NNcond)) ; ... 
    mean(rossi2.occur{FAtreat & ~NNcond,5}) ...
        mean(rossi2.occur{FAtreat & NNcond,5}) ...
        mean(rossi2.occur{~FAtreat & ~NNcond,5}) ...
        mean(rossi2.occur{~FAtreat & NNcond,5}); ... 
    mean(rossi2.occur{FAtreat & ~NNcond,6}) ...
        mean(rossi2.occur{FAtreat & NNcond,6}) ...
        mean(rossi2.occur{~FAtreat & ~NNcond,6}) ...
        mean(rossi2.occur{~FAtreat & NNcond,6}); ... 
    mean(rossi2.occur{FAtreat & ~NNcond,7}) ...
        mean(rossi2.occur{FAtreat & NNcond,7}) ...
        mean(rossi2.occur{~FAtreat & ~NNcond,7}) ...
        mean(rossi2.occur{~FAtreat & NNcond,7}) ... 
        }', ...
    'VariableNames',{'treatment','condition','meanPerAnt','stderrorPerAnt', ...
        'meanMOR','meanBiting','meanGastFlex'});

% Replication of Figure 3 from Rossi et al.  
figure;
bar( [ rossi2.sumAggr.meanPerAnt([1 3])...
        rossi2.sumAggr.meanPerAnt([2 4]) ]');
    hold on;
errorbar([.85 1.15; 1.85 2.15],[ rossi2.sumAggr.meanPerAnt([1 3])...
        rossi2.sumAggr.meanPerAnt([2 4]) ]', ...
        [ rossi2.sumAggr.stderrorPerAnt([1 3])...
        rossi2.sumAggr.stderrorPerAnt([2 4]) ]','o', ...
        'linewidth',2);
legend('Formic acid','Water');
set(gca,'xticklabel',{'nestmate','non-nestmate'});
title('Replication of Rossi et al. 2018, Figure 3A');
    

% Categorical assesment of confidence based on response type.
% 4 categories of response: none, MOR, bite, gaster flex. 
% For each ant we take the most aggressive response
% So the response "confidence" measure becomes as follows:
rossi2.occur{:,9} = max([rossi2.occur{:,5}>0, (rossi2.occur{:,6}>0)*2, (rossi2.occur{:,7}>0)*3],[],2);

% Non-categorical: confidence expressed as a sum of the number of responses.     
% Regardless of response type. 
rossi2.occur{:,10} = rossi2.occur{:,5} +   rossi2.occur{:,6} +   rossi2.occur{:,7};         
                                   

%% ---------------------------------------------------------------------
%               Figure 4 for main manuscript

% This just plots the data from the water condition, and only with
% confidence measured as the number of responses.

% Separate analysis of the ROCs - top give the cummulative proportions shown in panel A. 
% And criterion values for panel B.
[~, ~, respHist, ~, sdt] = RossiROC(rossi2,10,[0:200],1000,true);

f = figure('papersize',0.4*[25 8],'position',[100 20 50*25 50*8],'paperunits','centimeters');

% Plot the data as proportions of different actions. 
subplot('position',[.1 .15 .2 .7]);
dfltcolord = get(gca,'colororder');
tmp.NM = respHist.WatNM(1:37);
tmp.NNM = respHist.WatNonNM(1:37);
bh = bar([3 0], fliplr([tmp.NNM;zeros(1,37)]),0.8*0.3333,'stack');
hold on;
scale = ([1:1:11]/11)';
cmap_nnm = dfltcolord(2,:) + scale*(1-dfltcolord(2,:))
for i=1:11
    set(bh(i+26),'facecolor',cmap_nnm(i,:))
end;

bh = bar([1 0], fliplr([tmp.NM;zeros(1,37)]),.8,'stack');hold on;
scale = ([1:1:11]/11)';
cmap_nm = dfltcolord(1,:) + scale*(1-dfltcolord(1,:))
for i=1:11
    set(bh(i+26),'facecolor',cmap_nm(i,:))
end;
axis([0 4 0 36]);

[ys yis ] = unique(cumsum(tmp.NM));
nresp = fliplr(yis-1);
yvals = 34-ys; 
yadj = diff([0 ys])/2;
ts = arrayfun(@(x) sprintf('%d',x),nresp,'uni',false);
text(0.4*ones(length(yis),1),yvals+yadj,ts);
text(0.3,20,'# responses','rotation',-90);

[ys yis ] = unique(cumsum(tmp.NNM));
nresp = fliplr(yis-1);
yvals = 34-ys; 
yadj = diff([0 ys])/2;
ts = arrayfun(@(x) sprintf('%d',x),nresp,'uni',false);
text(3.5*ones(length(yis),1),yvals+yadj,ts)

ylim([0 34]);
set(gca,'ytick',[0:34/4:34],'yticklabel',[0:.25:1], ...
        'xtick',[1 3], 'xticklabel',{'nestmates','non-nestmates'});
box off;

ylabel('Proportion of trials for each response number','fontweight','bold'); 
text(0,37,'A. Ant''s responses','fontweight','bold');


% Plot a representation of the analysis as SDT. 
ah = subplot('position',[.38 .15 .2 .7]);
% N.B. Analysis does not give a single estimate of d'. Eye-balled single d's for display.
sdt.dp.Wat = 0.85; sdt.dp.For = 1.5; 
plotROCasSDT2(sdt,ah)

% Plot the ROC figure. 
ah = subplot('position',[.7 .15 .25 .7]);
plotRossiAntWaterRoc(rossi2,10,ah,[.85],[0:200],true,true,1); hold on;
title('');
text(0,1.1,'C. ROC analysis','fontweight','bold');






%% ---------------------------------------------------------------------
%       Supplementary Figure 2.


% A more detailed version of the basic data, showing water and formic acid
% conditions, and analysis based on both number of responses or response
% category
f = figure('papersize',0.4*[25 8],'position',[100 20 50*25 50*8],'paperunits','centimeters');

% ROC of the number of responses, for both water and formic adcid
% conditions.
ah = subplot('position',[.1 .15 .25 .7]);
plotRossiAntRoc(rossi2,10,ah,[.85 1.5],[0:200],true,true,1); hold on;
title('');
text(0,1.1,'A. ROC: # responses for all conditions','fontweight','bold');

% Plot of the number of different types of response in each 
% experimental condition.
ah = subplot('position',[.4 .15 .2 .7]);
bar([1 2 4 5], rossi2.sumAggr{1:4,5:7}, ...
       'stacked');
hold on;   
errorbar([1 2 4 5],rossi2.sumAggr.meanPerAnt(1:4), ...
                    rossi2.sumAggr.stderrorPerAnt(1:4),'o', ...
        'linewidth',2);
lh = legend('MOR','Biting','Gastor Flex');
set(lh,'box','off');
%legend('Formic acid','Water');
set(gca,'xtick',[1:4],'xticklabel',[]);
th = text([1 2 4 5]-.25,-.2*ones(1,4),{'NM','non-NM','NM','non-NM'});
th2 = text([1.25 4.25],[-.6 -.6],{'Formic acid (n=35)','Water (n=34)'});
ylabel('Number of actions (mean per ant)'); 
box off; xlim([.5 5.5]);
text(.5,7.6,'B. Number of each response type','fontweight','bold');

% Plot of the ROC analysis based on the category of response type
ah = subplot('position',[.7 .15 .25 .7]);
plotRossiAntRoc(rossi2,9,ah,[0.85,1.5],[0:3],true,true,0.5);
text(0.6,0.85,'MOR');
text(0.2,0.4,'biting');
text(0.1,0.1,'gastor flex');
title('');
text(0,1.1,'C. ROCs based on response type','fontweight','bold');


