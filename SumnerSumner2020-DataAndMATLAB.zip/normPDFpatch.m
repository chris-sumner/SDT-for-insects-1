function normPDFpatch(xvals,c,dp)

co = get(gca,'colororder');

% Produce slightly lighter than default colours.
h_col = co(1,:) + 0.5*(1-co(1,:))
f_col = co(2,:) + 0.5*(1-co(2,:))

fapatchx = [c xvals(xvals>c) ];
fapatchy = [0 normpdf(xvals(xvals>c),-dp/2,1) ];
hitpatchx =  [c xvals(xvals>c) ];
hitpatchy = [0 normpdf(xvals(xvals>c),dp/2,1) ];

hph = patch(hitpatchx,hitpatchy,h_col);
fph = patch(fapatchx,fapatchy,f_col);