function plotReevePrinciples(eg,ah)

xvals = [0:0.01:20];
init_sdtmodel;
lw = 1;

% Derive optimal decision criterion according to overall p.c.
cvals = [0.01:.01:20];

% As per reeve we reflect the normal distribution around the mean 
class1pdf = 2*normpdf(xvals,eg.means(1),eg.sds(1));
class1pdf = class1pdf/sum(class1pdf);

class2pdf = normpdf(xvals,eg.means(2),eg.sds(2));
class2pdf = class2pdf/sum(class2pdf);

% Function to calculate overall pc for a given criterion.
pcfn =  @(c) 0.5*sum(class1pdf(xvals<=c)) + ...
             0.5*sum(class2pdf(xvals>c));   
         
pc = arrayfun(@(c) pcfn(c), cvals);
pcmax = max(pc);
cmax = cvals( min(find(pc == pcmax)) );

% Now instead compute the optimal decision given the cost.
costfn =  @(c)eg.cost(1) * sum(class1pdf(xvals>c)) + ...
              eg.cost(2) * sum(class2pdf(xvals<=c));   
cost = arrayfun(@(c) costfn(c), cvals);
[costmin costmini] = min(cost);
ccostmin = cvals(costmini);

fapatchx = [cmax xvals(xvals>cmax) ];
fapatchy = eg.areas(1)*[0 normpdf(xvals(xvals>cmax),eg.means(1),eg.sds(1)) ];
hitpatchx =  [cmax xvals(xvals>cmax) ];
hitpatchy = eg.areas(2)*[0 normpdf(xvals(xvals>cmax),eg.means(2),eg.sds(2)) ];

subplot(ah);
l_fa = plot(xvals,eg.areas(1)*normpdf(xvals,eg.means(1),eg.sds(1)),'linewidth',lw); hold on;
l_h = plot(xvals,eg.areas(2)*normpdf(xvals,eg.means(2),eg.sds(2)),'linewidth',lw); 

h_col = get(l_h,'color'); h_col = h_col + 0.5*(1-h_col)
f_col = get(l_fa,'color'); f_col = f_col + 0.5*(1-f_col)

hph = patch(hitpatchx,hitpatchy,h_col);
fph = patch(fapatchx,fapatchy,f_col);

set(hph,'facealpha',1,'edgecolor',get(l_h,'color'));
set(fph,'facealpha',1,'edgecolor',get(l_fa,'color'));

% text(0.8,0.05,num2str(round(FAFn(eg.dp,eg.c),3)));
% text(eg.dp/2,0.2,num2str(round(HRFn(eg.dp,eg.c),3)));

%line([-eg.means(1) eg.means(2)],[0.41 0.41],'color','k','linewidth',1);
%text(-eg.dp/3,0.45,sprintf('d'' = %.2g',eg.dp));

line([cmax cmax],[0 0.2],'color',[.7 .7 .7],'linewidth',2);
text(cmax-0.55,0.22,sprintf('%.2g%% correct',100*pcmax));
text(cmax-0.55,0.25,'maximum % correct');
th = text(cmax+.4,.1,sprintf('c = %.2g',cmax));
set(th,'rotation',90,'color',[.5 .5 .5],'fontweight','bold');

line([ccostmin ccostmin],[0 0.4],'color',[.7 .7 .7],'linewidth',2);
text(ccostmin-0.55,0.42,sprintf('%.2g%% correct',100*pc(costmini)));
th = text(ccostmin+.4,.3,sprintf('c = %.2g',ccostmin));
set(th,'rotation',90,'color',[.5 .5 .5],'fontweight','bold');
text(ccostmin-0.55,0.45,'minimum cost of errors')

lh = legend('Stimulus class 1/Nestmate','Stimulus class 2/Non-nestmate'); set(lh,'box','off');

box off; 
xlim(eg.xlim);
ylim(eg.ylim);
set(gca,'ytick',[]);
xlabel('Sensory variable');
ylabel('Probability of response');

text(eg.xlim(1),eg.ylim(2)*1.04,eg.title,'fontweight','bold');

