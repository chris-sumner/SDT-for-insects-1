
%% ---------------- Figure 1 of Sumner & Sumner 2020 ------------

% Illustrates the principoels of signal deteciton theory 
% and the differences compared to the cons-specific acceptance 
% threshold model.

init_sdtmodel;


% Examples for signal detection theory
eg2.title = 'A. Signal Detection Theory, d''= 4';
eg2.dp = [4];
eg2.c = [0.2];
eg2.hr = HRFn(eg2.dp,eg2.c)

eg1.title = 'B. Signal Detection Theory, d''= 2';
eg1.dp = [2];
eg1.c = [.7];
eg1.hr = HRFn(eg1.dp,eg1.c)

eg3.title = 'C. Con-specific Acceptance Threshold';
eg3.means = [0 7];
eg3.sds = [2 3];
eg3.xlim = [0 16];
eg3.ylim = [0 0.7];
eg3.c = [2];
eg3.areas = [2 1];
eg3.cost = [1 10]; % Cost of false alarm is 3 x that of incorrect rejection.

figw_cm = 12;
figh_cm = 0.6*figw_cm;
f = figure('position',[100 20 60*figw_cm 60*figh_cm], ...
           'papersize',[figw_cm figh_cm]);

ah1 = subplot('position',[.1 .66 .35 .28]); 
plotSDTPrinciples(eg2,ah1);
xlabel('');

ah2 = subplot('position',[.1 .1 .35 .28]);
plotSDTPrinciples(eg1,ah2);
legend off;
ah3 = subplot('position',[.5 .1 .35 .84]);
plotReevePrinciples(eg3,ah3);
