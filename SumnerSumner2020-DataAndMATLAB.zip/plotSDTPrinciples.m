function plotSDTPrinciples(eg,ah)

xvals = [-10:0.01:10];
init_sdtmodel;
lw = 1;

fapatchx = [eg.c xvals(xvals>eg.c) ];
fapatchy = [0 normpdf(xvals(xvals>eg.c),-eg.dp/2,1) ];
hitpatchx =  [eg.c xvals(xvals>eg.c) ];
hitpatchy = [0 normpdf(xvals(xvals>eg.c),eg.dp/2,1) ];

subplot(ah);
l_fa = plot(xvals,normpdf(xvals,-eg.dp(1)/2,1),'linewidth',lw); hold on;
l_h = plot(xvals,normpdf(xvals,eg.dp(1)/2,1),'linewidth',lw); 

h_col = get(l_h,'color'); h_col = h_col + 0.5*(1-h_col)
f_col = get(l_fa,'color'); f_col = f_col + 0.5*(1-f_col)

hph = patch(hitpatchx,hitpatchy,h_col);
set(hph,'facealpha',1,'edgecolor',get(l_h,'color'));
fph = patch(fapatchx,fapatchy,f_col);
set(fph,'facealpha',1,'edgecolor',get(l_fa,'color'));

text(1,0.1,num2str(round(FAFn(eg.dp,eg.c),3)),'color',get(l_fa,'color'),'fontweight','bold');
text(eg.dp,0.2,num2str(round(HRFn(eg.dp,eg.c),3)),'color',get(l_h,'color'),'fontweight','bold');

line([-eg.dp/2 eg.dp/2],[0.41 0.41],'color','k','linewidth',1);
text(-eg.dp/3-.5,0.45,sprintf('d'' = %.2g',eg.dp));

line([eg.c eg.c],[0 0.7],'color',[.7 .7 .7],'linewidth',2);
th = text(eg.c+.4,.43,sprintf('c = %.2g',eg.c));
set(th,'rotation',90,'color',[.5 .5 .5],'fontweight','bold');

lh = legend('Stimulus class 1/No-tone','Stimulus class 2/Tone'); 
set(lh,'box','off','location','east');

box off; 
xlim([-6 6]);
ylim([0 .6]);
set(gca,'ytick',[]);
xlabel('Sensory variable');
ylabel('Probability of response');

text(-5.8,.68,eg.title,'fontweight','bold');

