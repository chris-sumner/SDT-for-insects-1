
%% --------------- Figure S2 from Sumner&Sumner Royal.Soc. 2020  ------------------

% Stingless bee data originally published by Coubillon et al. (2013):
% Couvillon, M. J., Segers, F. H. I. D., Cooper-Bowman, R., Truslove, G., 
% Nascimento, D. L., Nascimento, F. S. & Ratnieks, F. L. W. (2013) 
% Context affects nestmate recognition errors in honey bees and stingless bees. 
% J Exp Biol 216, 3055-3061. (DOI:10.1242/jeb.085324).
% Data was provided by Francisca Segers, reformatted slightly for the data analysis.

% Initialise functions for SDT.
init_sdtmodel

% Load up the honeybee data.
stingless.data = readtable('stinglessbee.csv') 

% Make table of statistics.
stingless.stats = unstack(stingless.data,'Response','NMBee','GroupingVariables','Treatment','AggregationFunction', @mean);
stingless.stats.Properties.VariableNames = {'Treatment','NNM','NM'};
stingless.stats.TreatmentName = {'T1.Gd1Od0','T2.Gd2Od0','T3.Gd1Od1','T4.Gd2Od1','hive'}';
% Add in d' analysis.
ntmp = unstack(stingless.data,'Response','NMBee','GroupingVariables','Treatment','AggregationFunction', @length);
ntmp.Properties.VariableNames = {'Treatment','NNM','NM'};
stingless.stats.n_NM = ntmp.NM; stingless.stats.n_NNM = ntmp.NNM;
stingless.stats.Z_NM = Zfn(stingless.stats.NM);
stingless.stats.Z_NNM = Zfn(stingless.stats.NNM);
stingless.stats.dprime = dPrimeFn(stingless.stats.NM,stingless.stats.NNM);
stingless.stats.c = cCritFn(stingless.stats.NM,stingless.stats.NNM);

% Make a structure for the SDT plot.
treatmentOrder = [5 4 3 2 1];
stingless.sdt.title = 'Couvillon et al. (2013). Fig. 2A. Stingless bee';
stingless.sdt.hr = stingless.stats.NM(treatmentOrder)';  % Put in the order of Couvillon.  
stingless.sdt.fa =  stingless.stats.NNM(treatmentOrder)';
stingless.sdt.IVname = '% acceptance';
stingless.sdt.DVnames = stingless.stats.TreatmentName(treatmentOrder)';
stingless.sdt.HitClass = 'Nestmate';
stingless.sdt.FAClass = 'Non-nestmate';
stingless.sdt.dp = stingless.stats.dprime(treatmentOrder)';
stingless.sdt.c = stingless.stats.c(treatmentOrder)';
stingless.sdt.species = 'stingless bee';

% Plot for the paper. 
sh = plotCouvillonFig_v3(stingless.sdt);


