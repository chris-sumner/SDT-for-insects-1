function [roc, pvals, respHist, rocboot, sdt] = RossiROC(data,measi,cat,nboot,cumflag)
%[roc,pvals,respHist] = RossiROC(data,cat,cumflag)

init_sdtmodel;

% Function to compute the cummulative rating probability.
% This is a measure of "confidence" that the ant is not a nestmate.
% N.B. Ratings must be from least confident to most - so flip before 
% summing. 
% Also last point is by definition at 1,1 so don't include 1st point.
if nargin<5 || cumflag==true
    cumProbBootFn = @(x) cumsum(x(2:end,:),1,'reverse');
    cumProbFn = @(x) cumsum(fliplr(x(2:end)));
else 
    cumProbBootFn = @(x) x;
    cumProbFn = @(x) x;
end;

% x values for norm cdf plots. 
pvals = [-3:.01:3];
% Flags for each condition
FAtreat =  strcmp(data.occur.Treatment,'formic acid');
NNcond =  strcmp(data.occur.Condition,'non-nestmate');

% Compute the PDFs of the responses. 
respHist.ForNonNM = hist(data.occur{FAtreat & NNcond,measi},cat);
respHist.ForNM = hist(data.occur{FAtreat & ~NNcond,measi},cat);
respHist.WatNM = hist(data.occur{~FAtreat & ~NNcond,measi},cat);
respHist.WatNonNM = hist(data.occur{~FAtreat & NNcond,measi},cat);
respHist.title = 'Rossi et al. 2018';

% Convert counts of actions to CDFs. 
roc.ForNonNM = cumProbFn(respHist.ForNonNM/sum(respHist.ForNonNM));
roc.ForNM = cumProbFn(respHist.ForNM/sum(respHist.ForNM));
roc.WatNM = cumProbFn(respHist.WatNM/sum(respHist.WatNM));
roc.WatNonNM = cumProbFn(respHist.WatNonNM/sum(respHist.WatNonNM));
roc.title = respHist.title;

% d' calculated from the mean z(FA) and z(H) values. 
% N.B. this is extremely crude. 
% Need to use a max likelihood procedure to get it right. 
% Hence I eyeballed it for the figures. 
sdt.dp.Wat = sum(dPrimeFn(roc.WatNonNM,roc.WatNM))/ ...
             sum(dPrimeFn(roc.WatNonNM,roc.WatNM)>0);
sdt.dp.For = sum(dPrimeFn(roc.ForNonNM,roc.ForNM))/ ...
            sum(dPrimeFn(roc.ForNonNM,roc.ForNM)>0);

% c values    cCritFn  
sdt.c.Wat = cCritFn(roc.WatNonNM,roc.WatNM);
sdt.c.For = cCritFn(roc.ForNonNM,roc.ForNM);

        
% If the option to bootstrap is there, calculate the distribution margins
% by resmapling with replacement.
if nboot>0
    % Formic acid nestmates. 
    rocboot.ForNonNM = bootStrap(data.occur{FAtreat & NNcond,measi},cat,nboot,cumProbBootFn);
    % Formic acid nestmates. 
    rocboot.ForNM = bootStrap(data.occur{FAtreat & ~NNcond,measi},cat,nboot,cumProbBootFn);
    
    % Water non-nestmates. 
    rocboot.WatNonNM = bootStrap(data.occur{~FAtreat & NNcond,measi},cat,nboot,cumProbBootFn);
     % Water nestmates. 
    rocboot.WatNM = bootStrap(data.occur{~FAtreat & ~NNcond,measi},cat,nboot,cumProbBootFn);
end;
        
        
        


function rocboot = bootStrap(data,cat,nboot,cumProbFn)
    ForNonNM_1 =   data;       % Original data.
    ForNonNM_n = length( ForNonNM_1 );                    % Number of samples
    ForNonNM_i = randi(ForNonNM_n, ForNonNM_n, nboot );    % Random resmapling indexes
    ForNonNM_boot = zeros( ForNonNM_n, nboot );           % Pre-allocate storage     
    ForNonNM_boot(1:ForNonNM_n*nboot) = ForNonNM_1( ForNonNM_i );   % Resampled data.
    
    % Make histgrams of each iteration
    ForNonNM_hist = hist(ForNonNM_boot,cat);
    % Convert to cdfs
    ForNonNM_cdf = cumProbFn( ForNonNM_hist/ForNonNM_n );

    % Extract the raw values.
    rocboot.raw = ForNonNM_cdf;
    
    % Extract statistics for each iteration.
    rocboot.grandmeans = mean( ForNonNM_cdf ,2 );
    rocboot.sd = std( ForNonNM_cdf ,[],2 );
    rocboot.quantiles = quantile(ForNonNM_cdf,[.025 0.25 0.5 .75 .975],2);
      
        
    


